package com.example.calculadora


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView


class MainActivity : AppCompatActivity() {

    private val TAG : String ="MainActivity"
    private val TextoArriba:String="TextoArriba"
    private val TextoAbajo:String="TextoAbajo"

    //Creación de objetos para las operaciones

    companion object{
        const val sumar=1
        const val restar=2
        const val  multiplicar=3
        const val dividir =4
    }

    //Creación de variables para num1, num2 y operacion
    private var num1: Double = 0.0
    private var num2: Double = 0.0
    private var operacion: Int = 0
    private var resultadosTV: TextView? = null
    private var mostrarNumTV: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        resultadosTV= findViewById(R.id.resultadosTV)
        mostrarNumTV= findViewById(R.id.mostrar_numTV)

        //Crear variables de los botones numéricos utilizando su ID
        val botonCero: Button = findViewById(R.id.boton_cero)
        val botonUno: Button = findViewById(R.id.boton_uno)
        val botonDos: Button = findViewById(R.id.boton_dos)
        val botonTres: Button = findViewById(R.id.boton_tres)
        val botonCuatro: Button = findViewById(R.id.boton_cuatro)
        val botonCinco: Button = findViewById(R.id.boton_cinco)
        val botonSeis: Button = findViewById(R.id.boton_seis)
        val botonSiete: Button = findViewById(R.id.boton_siete)
        val botonOcho: Button = findViewById(R.id.boton_ocho)
        val botonNueve: Button = findViewById(R.id.boton_nueve)

        //Crear variables de los botones de las operaciones utilizando su ID
        val botonSuma: Button = findViewById(R.id.boton_suma)
        val botonResta: Button = findViewById(R.id.boton_resta)
        val botonMultiplicacion: Button = findViewById(R.id.boton_mult)
        val botonDivision: Button = findViewById(R.id.boton_div)

        //Crear variable del botón de borrar (clear) utilizando su ID
        val botonClear: Button = findViewById(R.id.boton_clear)

        //Crear variable del botón de igual utilizando su ID
        val botonIgual: Button = findViewById(R.id.boton_igual)

        //Crear variable del botón de punto decimal utilizando su ID
        val botonPunto: Button = findViewById(R.id.boton_punto)

        //setOnClickListener{} para que se pueda dar click en los botones numéricos
        botonCero.setOnClickListener{(clickNum("0"))}
        Log.d(TAG, "/nButtn 0")
        botonUno.setOnClickListener{(clickNum("1"))}
        botonDos.setOnClickListener{(clickNum("2"))}
        botonTres.setOnClickListener{(clickNum("3"))}
        botonCuatro.setOnClickListener{(clickNum("4"))}
        botonCinco.setOnClickListener{(clickNum("5"))}
        botonSeis.setOnClickListener{(clickNum("6"))}
        botonSiete.setOnClickListener{(clickNum("7"))}
        botonOcho.setOnClickListener{(clickNum("8"))}
        botonNueve.setOnClickListener{(clickNum("9"))}

        //setOnClickListener{} para que se pueda dar click en los botones de las operaciones
        botonSuma.setOnClickListener{clickOp(sumar)}
        botonResta.setOnClickListener{clickOp(restar)}
        botonMultiplicacion.setOnClickListener{clickOp(multiplicar)}
        botonDivision.setOnClickListener{clickOp(dividir)}

        //setOnClickListener{} para que se pueda dar click en el boton de clear
        botonClear.setOnClickListener{clear()}

        //setOnClickListener{} para que se pueda dar click en el boton de igual
        botonIgual.setOnClickListener{resultadosOps(operacion)}

        //setOnClickListener{} para que se pueda dar click en el boton de punto decimal
        botonPunto.setOnClickListener{clickNum(".")}
    }
    //Creación de la variable del TextView (resultadosTV) utilizando su ID


    //Función para hacer que los números a los que des click se concatenen y guarden en el TextView de los resultados.
    fun clickNum(digit:String){
     resultadosTV?.text="${resultadosTV?.text}$digit"
        if (operacion==0){
            num1=resultadosTV?.text.toString().toDouble()
            mostrarNumTV?.append(digit)
        }else{
            num2=resultadosTV?.text.toString().toDouble()
            mostrarNumTV?.append(digit)
        }
    }

    //Funcion Operaciones
    private fun clickOp(op: Int){
        operacion=op
        mostrarNumTV?.text=""
        mostrarNumTV?.append(num1.toString())
        if(op==1)
        {
            mostrarNumTV?.append("+")
        }else if(op==2)
        {
            mostrarNumTV?.append("-")
        }else if(op==3){
            mostrarNumTV?.append("×")
        }else if (op==4){
            mostrarNumTV?.append("÷")
        }
        resultadosTV?.text=""
        Log.d(TAG,"Operacion="+operacion)
    }
//Función clear: reestablece todos las las variables a su valor inicial.
    private fun clear(){
        num1=0.0
        num2=0.0
        operacion=0
        resultadosTV?.text=""
    }

    //Funcion Resultados (igual)

    private fun resultadosOps(operacion: Int){
        var result=0.0
        if(operacion==sumar){
            result=num1+num2
        }
        if(operacion==restar){
            result=num1-num2
        }
        if(operacion== multiplicar){
            result=num1*num2
        }
        if(operacion== dividir){
            result=num1/num2
        }
        resultadosTV?.text=result.toString()
        mostrarNumTV?.append("=")
        num1=result
        num2=0.0
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString(TextoAbajo,resultadosTV?.text.toString())
        outState.putString(TextoArriba,mostrarNumTV?.text.toString())
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        resultadosTV?.text=savedInstanceState.getString(TextoAbajo)
        mostrarNumTV?.text=savedInstanceState.getString(TextoArriba)
    }
} //Llave de cierre de MainActivity()